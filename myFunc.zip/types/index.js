"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isIncomingWebhookSendArguments = (arg) => {
    if (arg === null || typeof arg !== "object") {
        return false;
    }
    if (arg.text !== undefined && typeof arg.text !== "string") {
        return false;
    }
    if (arg.link_names !== undefined && typeof arg.link_names !== "boolean") {
        return false;
    }
    if (arg.attachments !== undefined && !Array.isArray(arg.attachments)) {
        return false;
    }
    if (arg.blocks !== undefined && !Array.isArray(arg.blocks)) {
        return false;
    }
    if (arg.unfurl_links !== undefined && typeof arg.unfurl_links !== "boolean") {
        return false;
    }
    if (arg.unfurl_media !== undefined && typeof arg.unfurl_media !== "boolean") {
        return false;
    }
    // 空のオブジェクトを誤認してしまうのでプロパティが一つもなければfalseを返す
    if (arg.text === undefined &&
        arg.link_names == undefined &&
        arg.attachments == undefined &&
        arg.blocks == undefined &&
        arg.unfurl_links == undefined &&
        arg.unfurl_media == undefined) {
        return false;
    }
    // File を誤認してしまわないようにこのチェックも加える
    if (Buffer.isBuffer(arg.buffer)) {
        return false;
    }
    return true;
};
exports.isEventType = (arg) => {
    if (arg === null || typeof arg !== "object") {
        return false;
    }
    if (arg.channel !== undefined && typeof arg.channel !== "string") {
        return false;
    }
    if (arg.name !== undefined && typeof arg.name !== "string") {
        return false;
    }
    if (arg.username !== undefined && typeof arg.username !== "string") {
        return false;
    }
    if (arg.icon !== undefined && typeof arg.icon !== "string") {
        return false;
    }
    if (arg.user_icon !== undefined && typeof arg.user_icon !== "string") {
        return false;
    }
    if (arg.text !== undefined && typeof arg.text !== "string" && !exports.isIncomingWebhookSendArguments(arg.text)) {
        return false;
    }
    if (arg.base64 !== undefined && typeof arg.base64 !== "string") {
        return false;
    }
    if (arg.filename !== undefined && typeof arg.filename !== "string") {
        return false;
    }
    if (arg.mode !== undefined && arg.mode !== "snippet") {
        return false;
    }
    return true;
};
