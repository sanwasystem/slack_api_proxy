"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
// eslint-disable-next-line @typescript-eslint/no-var-requires
const Busboy = require("busboy");
const _ = __importStar(require("lodash"));
/**
 * 適当に拡張子とMIME tyepとを並べたもの
 */
const extentionContentTypeMap = {
    aac: "audio/aac",
    abw: "application/x-abiword",
    arc: "application/octet-stream",
    avi: "video/x-msvideo",
    azw: "application/vnd.amazon.ebook",
    bin: "application/octet-stream",
    bmp: "image/bmp",
    bz: "application/x-bzip",
    bz2: "application/x-bzip2",
    csh: "application/x-csh",
    css: "text/css",
    csv: "text/csv",
    doc: "application/msword",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    eot: "application/vnd.ms-fontobject",
    epub: "application/epub+zip",
    es: "application/ecmascript",
    gif: "image/gif",
    gzip: "multipart/x-gzip",
    htm: "text/html",
    html: "text/html",
    ico: "image/x-icon",
    ics: "text/calendar",
    jar: "application/java-archive",
    jpeg: "image/jpeg",
    jpg: "image/jpeg",
    js: "application/javascript",
    json: "application/json",
    mid: "audio/midi audio/x-midi",
    midi: "audio/midi audio/x-midi",
    mpeg: "video/mpeg",
    mpkg: "application/vnd.apple.installer+xml",
    odp: "application/vnd.oasis.opendocument.presentation",
    ods: "application/vnd.oasis.opendocument.spreadsheet",
    odt: "application/vnd.oasis.opendocument.text",
    oga: "audio/ogg",
    ogv: "video/ogg",
    ogx: "application/ogg",
    otf: "font/otf",
    png: "image/png",
    pdf: "application/pdf",
    ppt: "application/vnd.ms-powerpoint",
    pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    rar: "application/x-rar-compressed",
    rtf: "application/rtf",
    sh: "application/x-sh",
    svg: "image/svg+xml",
    swf: "application/x-shockwave-flash",
    tar: "application/x-tar",
    txt: "text/plain",
    text: "text/plain",
    tif: "image/tiff",
    tiff: "image/tiff",
    ts: "application/typescript",
    ttf: "font/ttf",
    vsd: "application/vnd.visio",
    wav: "audio/wav",
    weba: "audio/webm",
    webm: "video/webm",
    webp: "image/webp",
    woff: "font/woff",
    woff2: "font/woff2",
    xhtml: "application/xhtml+xml",
    xls: "application/vnd.ms-excel",
    xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    xml: "application/xml",
    xul: "application/vnd.mozilla.xul+xml",
    zip: "application/zip",
    "3gp": "video/3gpp",
    "3g2": "video/3gpp2",
    "7z": "application/x-7z-compressed"
};
// eslint-disable-next-line @typescript-eslint/no-explicit-any
exports.isFile = (arg) => {
    if (arg === null || typeof arg !== "object") {
        return false;
    }
    if (arg.fileName === undefined && typeof arg.fileName !== "string") {
        return false;
    }
    if (arg.encoding === undefined && typeof arg.encoding !== "string") {
        return false;
    }
    if (arg.contentType === undefined && typeof arg.contentType !== "string") {
        return false;
    }
    if (!Buffer.isBuffer(arg.buffer)) {
        return false;
    }
    return true;
};
exports.getContentTypeFromExtention = (fileName) => {
    var _a;
    if (!fileName) {
        return "application/octet-stream";
    }
    const extention = (_a = _.last(fileName.split(".")), (_a !== null && _a !== void 0 ? _a : ""));
    const result = extentionContentTypeMap[extention];
    return (result !== null && result !== void 0 ? result : "application/octet-stream");
};
exports.parse = (buffer, contentType) => {
    const result = {};
    return new Promise(resolve => {
        const busboy = new Busboy({
            headers: { "content-type": contentType }
        });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        busboy.on("file", (fieldName, file, fileName, encoding, mimeType) => {
            file.on("data", (content) => {
                if (!mimeType || mimeType === "octet-stream" || mimeType === "application/octet-stream") {
                    mimeType = exports.getContentTypeFromExtention(fileName);
                }
                result[fieldName] = {
                    fileName,
                    encoding,
                    buffer: content,
                    contentType: mimeType
                };
            });
        });
        busboy.on("field", (fieldName, value, fieldnameTruncated, valTruncated, encoding, mimeType) => {
            result[fieldName] = value;
        });
        busboy.on("finish", () => {
            resolve(result);
        });
        busboy.write(buffer);
    });
};
exports.getString = (multiPartFormParseResult, name) => {
    const result = multiPartFormParseResult[name];
    if (typeof result !== "string") {
        return undefined;
    }
    return result;
};
exports.getFile = (multiPartFormParseResult, name) => {
    const result = multiPartFormParseResult[name];
    if (result === undefined || typeof result === "string") {
        return undefined;
    }
    return result;
};
