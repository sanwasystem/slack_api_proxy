"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * API GatewayのLambda Proxyで呼び出されるLambdaはこれを使って結果を返す
 */
exports.completeForAPIGateway = (obj, statusCode = 200, headers = {}) => {
    if (typeof obj == "object") {
        obj = JSON.stringify(obj);
    }
    const result = {
        statusCode: statusCode,
        body: obj,
        headers: Object.assign({}, headers)
    };
    result.headers["Content-Type"] = result.headers["Content-Type"] || "application/json; charset=utf-8";
    result.headers["Access-Control-Allow-Origin"] = result.headers["Access-Control-Allow-Origin"] || "*";
    return result;
};
exports.getBodyAsBuffer = (event) => {
    var _a;
    const body = (_a = event.body, (_a !== null && _a !== void 0 ? _a : ""));
    return Buffer.from(body, event.isBase64Encoded ? "base64" : "utf-8");
};
exports.getContentType = (headers) => {
    for (const name of Object.keys(headers)) {
        if (name.toLowerCase() === "content-type") {
            return headers[name];
        }
    }
    return "octet-stream";
};
exports.wrapWithColon = (str) => {
    if (!/^:/.test(str)) {
        str = ":" + str;
    }
    if (!/:$/.test(str)) {
        str = str + ":";
    }
    return str;
};
exports.neverComesHere = (arg) => {
    throw new Error(arg);
};
