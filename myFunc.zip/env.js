"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv = __importStar(require("dotenv"));
dotenv.config();
// 指定した名前の環境変数を返す。定義されていなければ例外をスローする
const getEnv = (name) => {
    const result = process.env[name];
    if (result === undefined) {
        throw new Error(`environment variable "${name}" not defined`);
    }
    return result;
};
const defaultChannel = getEnv("defaultChannel");
exports.defaultChannel = defaultChannel;
const defaultName = getEnv("defaultName");
exports.defaultName = defaultName;
const defaultIcon = getEnv("defaultIcon");
exports.defaultIcon = defaultIcon;
const webhookUrl = getEnv("webhookUrl");
exports.webhookUrl = webhookUrl;
const botToken = getEnv("botToken");
exports.botToken = botToken;
