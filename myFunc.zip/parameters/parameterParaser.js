"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const util = __importStar(require("../util"));
const env = __importStar(require("../env"));
const parser = __importStar(require("../multipartFormBodyParser"));
const Types = __importStar(require("../types"));
exports.parsePost = (event) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e;
    const contentType = util.getContentType(event.headers);
    const buffer = util.getBodyAsBuffer(event);
    const multiPart = yield parser.parse(buffer, contentType);
    console.log("POST request. parameter:");
    console.log(JSON.stringify(multiPart));
    const channel = (_a = parser.getString(multiPart, "channel"), (_a !== null && _a !== void 0 ? _a : env.defaultChannel));
    const username = (_c = (_b = parser.getString(multiPart, "name"), (_b !== null && _b !== void 0 ? _b : parser.getString(multiPart, "username"))), (_c !== null && _c !== void 0 ? _c : env.defaultName));
    const icon = (_e = (_d = parser.getString(multiPart, "icon"), (_d !== null && _d !== void 0 ? _d : parser.getString(multiPart, "user_icon"))), (_e !== null && _e !== void 0 ? _e : env.defaultIcon));
    const textStr = parser.getString(multiPart, "text");
    const textFile = parser.getFile(multiPart, "text");
    const text = (textStr !== null && textStr !== void 0 ? textStr : textFile);
    const file = parser.getFile(multiPart, "file");
    const filename = parser.getString(multiPart, "filename");
    const mode = parser.getString(multiPart, "mode");
    return { channel, username, icon, text, file, filename, mode };
});
exports.parseGet = (event) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o;
    console.log("GET request. parameter:");
    console.log(JSON.stringify(event.queryStringParameters));
    const channel = (_b = (_a = event.queryStringParameters) === null || _a === void 0 ? void 0 : _a.channel, (_b !== null && _b !== void 0 ? _b : env.defaultChannel));
    const username = (_f = (_d = (_c = event.queryStringParameters) === null || _c === void 0 ? void 0 : _c.name, (_d !== null && _d !== void 0 ? _d : (_e = event.queryStringParameters) === null || _e === void 0 ? void 0 : _e.username)), (_f !== null && _f !== void 0 ? _f : env.defaultName));
    const icon = (_k = (_h = (_g = event.queryStringParameters) === null || _g === void 0 ? void 0 : _g.icon, (_h !== null && _h !== void 0 ? _h : (_j = event.queryStringParameters) === null || _j === void 0 ? void 0 : _j.user_icon)), (_k !== null && _k !== void 0 ? _k : env.defaultIcon));
    const text = (_l = event.queryStringParameters) === null || _l === void 0 ? void 0 : _l.text;
    const file = undefined;
    const filename = (_m = event.queryStringParameters) === null || _m === void 0 ? void 0 : _m.filename;
    const mode = (_o = event.queryStringParameters) === null || _o === void 0 ? void 0 : _o.mode;
    return { channel, username, icon, text, file, filename, mode };
};
exports.parseDirect = (event) => {
    var _a, _b, _c, _d, _e, _f, _g;
    console.log("direct lambda execution. parameter:");
    console.log(JSON.stringify(event));
    if (!Types.isEventType(event)) {
        throw new Error(`malformed parameter`);
    }
    let file = undefined;
    const filename = (_a = event.filename, (_a !== null && _a !== void 0 ? _a : "unknown.dat"));
    if (event.base64) {
        const buffer = Buffer.from((_b = event.base64, (_b !== null && _b !== void 0 ? _b : "")), "base64");
        file = {
            buffer: buffer,
            fileName: filename,
            contentType: parser.getContentTypeFromExtention(filename),
            encoding: ""
        };
    }
    return {
        channel: (_c = event.channel, (_c !== null && _c !== void 0 ? _c : env.defaultChannel)),
        username: (_e = (_d = event.name, (_d !== null && _d !== void 0 ? _d : event.username)), (_e !== null && _e !== void 0 ? _e : env.defaultName)),
        icon: (_g = (_f = event.icon, (_f !== null && _f !== void 0 ? _f : event.user_icon)), (_g !== null && _g !== void 0 ? _g : env.defaultIcon)),
        text: event.text,
        file: file,
        filename: event.filename,
        mode: event.mode
    };
};
