"use strict";
// slack api proxy v1.0.0
// https://github.com/sanwasystem/slack_api_proxy
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const util = __importStar(require("./util"));
const parameters = __importStar(require("./parameters"));
const token = __importStar(require("./tokenManager"));
const web_api_1 = require("@slack/web-api");
const webhook = __importStar(require("./webhookClient"));
const neverComesHere = (arg) => {
    throw new Error(arg);
};
exports.handler = (
// eslint-disable-next-line @typescript-eslint/no-explicit-any
event, 
// eslint-disable-next-line @typescript-eslint/no-unused-vars
context) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const param = yield parameters.parse(event);
        switch (param.mode) {
            case "File": {
                const botToken = yield token.getToken(param.channel);
                const web = new web_api_1.WebClient(botToken);
                const result = yield web.files.upload({
                    channels: param.channel,
                    filename: param.filename,
                    file: param.buffer
                });
                if (result.ok) {
                    return util.completeForAPIGateway("OK");
                }
                else {
                    return util.completeForAPIGateway(JSON.stringify(result.response_metadata), 500);
                }
            }
            case "Text": {
                const url = yield token.getWebhookUrl(param.channel);
                let payload;
                if (typeof param.message === "string") {
                    payload = {
                        channel: param.channel,
                        username: param.username,
                        icon_emoji: util.wrapWithColon(param.icon),
                        text: param.message
                    };
                }
                else {
                    payload = Object.assign({ channel: param.channel, username: param.username, icon_emoji: util.wrapWithColon(param.icon) }, param.message);
                }
                console.log(payload);
                yield webhook.postMessage(url, payload).catch(e => {
                    return util.completeForAPIGateway(e, 500);
                });
                return util.completeForAPIGateway("OK", 200);
            }
            default: {
                return neverComesHere(param);
            }
        }
    }
    catch (e) {
        return util.completeForAPIGateway(e, 500);
    }
});
