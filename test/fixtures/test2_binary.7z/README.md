# slack_api_proxy
SlackのIncoming Webhook, File upload APIをラップするLambda
